// SPDX-License-Identifier: MIT
pragma solidity ^0.8.9;

import "./@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract Quokka is ERC20 {
    constructor() ERC20("QuokkaCoin", "QKA") {
        _mint(msg.sender, 49396002 * 10 ** decimals());
    }
}
