// SPDX-License-Identifier: MIT
pragma solidity ^0.8.9;

import "./@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract Quokka is ERC20 {
    constructor() ERC20("Quokka", "QKA") {
        _mint(msg.sender, 50000000 * 10 ** decimals());
    }
}
